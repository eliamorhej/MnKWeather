<?php

namespace App\Http\Controllers\Main;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\User;
use App\Models\PinnedLocation;
use App\Http\Controllers\Main\SearchController;

class HomeController extends Controller
{
    public function index()
    {       
        return view("main.home",["userPinned"=>$this->getWeatherInfo(),"local"=>$this->localWeather()]);
    }
    private function localWeather()
    {
        $cont = new SearchController();
        return $cont->getByName("toronto");
    }
    private function getWeatherInfo()
    {
        
        $pinned = array();
        if( Auth::user() )
        {
            $userLocations = PinnedLocation::getAll(Auth::user()->getAttributes()['username'])->get();
            $cont = new SearchController();
            //dd(Auth::user()->getAttributes()['username']);
            
            foreach($userLocations as $x)
            {
                $pinned[] = $cont->getByID($x->id);
            }
            
        }
        //dd($pinned);
        return $pinned;
    }
}
