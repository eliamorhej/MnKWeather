
<?php $__env->startSection('title','Home'); ?>
<?php $__env->startSection('content'); ?>
<div class='container'>
    
    <h1 class="text-center m-5" >Search Results</h1> 
    <?php
        if(!$sr)
        {
            echo("<div>no results</div>");
        }
        foreach($sr as $result)
        {
            echo('  
            <div class="row">
            <h2>'.$result["name"].', '.(isset($result["country"])?$result["country"]:" ").'</h2>
            <div class="col-md-3">
                temperature: '.$result["main"]["temp"].'C
            </div>'.'<div class="col-md-3">humidity: '.$result["main"]["humidity"].'%</div></div>');
            
            echo("<div class='col-md-3'><a href=".'/pin/'.$result['id'].">Home</a></div>");
            echo("</br>");
        }
    ?>
</div>

<script>
var tableFields = document.getElementById("navbarButtonsDiv");
var children = tableFields.children;
for (var i = 0; i < children.length; i++) {
    var element = children[i];
    if(element.classList.contains("active"))
    {
        element.classList.remove('active');
        element.setAttribute("aria-current","none");
        break;
    }
}        
</script>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\MnKWeather\resources\views/main/search.blade.php ENDPATH**/ ?>