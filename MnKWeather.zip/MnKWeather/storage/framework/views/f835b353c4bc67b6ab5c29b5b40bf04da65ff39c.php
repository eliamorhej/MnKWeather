<?php $__env->startSection('title','Home'); ?>
<?php $__env->startSection('content'); ?>
<div class="jumbotron" style="background:url('https://www.nasa.gov/sites/default/files/styles/ubernode_alt_horiz/public/thumbnails/image/smap-weather.jpg');background-repeat:no-repeat;
    background-size:100% 100vh;">
    <div class="container">
    <div class='row'>   
            <div class="col-sm">
            <div>
                <h2 class="display-2"><strong>Today's Weather in <?php echo($local["name"]);echo(": </br>");
                echo($local["main"]->temp ."C");?></strong></h2>
</br>
                <p class="textmb-0"><strong><?php echo("The wind is traveling at ".$local["wind"]->speed."m/s</br>");?></strong></p>
                <p class="textmb-0"><strong><?php echo("The sky is clouded by about ".$local["clouds"]->all."%");?></strong></p>
            </div>
            </div>
        </div>   
    </div>  
</div>
<div class='container'>
    <div class='row'>
        <div class='col-md-12'>
            <h1 >Your Pinned Locations:</h1>
        </div>
        <?php if($errors->any()): ?>
        <div class="text-danger mt-2 text-sm"><?php echo e($errors->first('message')); ?></div> 
        <?php endif; ?>
        <?php
            if(!$userPinned)
            {
                echo('<div class="row">
                <div class="col-sm">
                    <div class="card m-4 gradient-custom" style="border-radius: 25px;">
                        <div class="card-body p-4">
                            <div class="d-flex justify-content-between mb-4 pb-2">
                                <div>
                                    <h2 class="display-2"><strong></strong></h2>
                                    <p class="text-muted mb-0"></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                </div>');
            }
            else
            {
                $counter = 1;
                foreach($userPinned as $loc)
                {
                    if($counter == 1)
                    {
                        echo('<div class="row"></div>');
                        $counter++;
                    }
                    else{
                        $counter = 1;
                    }
                    $tempid = $loc['id'];
                    echo('
                    <div class="col-sm" id='.$tempid.'>
                        <div class="card m-4 gradient-custom" style="border-radius: 25px;">
                            <div class="card-body p-4">
                            <button href="{{ route(register) }}" style="float:right;border:none;"><img width="20px" height="20px" src="https://external-content.duckduckgo.com/iu/?u=http%3A%2F%2Fcdn.onlinewebfonts.com%2Fsvg%2Fimg_489668.png&f=1&nofb=1"></button>
                                <div class="d-flex justify-content-between mb-4 pb-2">
                                    <div>
                                        <h2 class="display-2"><strong>'.$loc["main"]->temp.'C</strong></h2>
                                        <p class="text mb-2">'.$loc["name"].','.$loc["sys"]->country.'</p>
                                        <p class="text-mb2">'.$loc["main"]->humidity.'% humid today</p>
                                        </br>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>');
                }
            }
        ?>
        
    </div>
</div>
<script>
    var tableFields = document.getElementById("navbarButtonsDiv");
    var children = tableFields.children;
    for (var i = 0; i < children.length; i++) {
        var element = children[i];
        if(element.classList.contains("active"))
        {
            element.classList.remove('active');
            element.setAttribute("aria-current","none");
            break;
        }
    }
    var reg = document.getElementById("home");
    reg.classList.add('active');                  
    reg.setAttribute("aria-current", "page");           
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\MnKWeather\resources\views/main/home.blade.php ENDPATH**/ ?>