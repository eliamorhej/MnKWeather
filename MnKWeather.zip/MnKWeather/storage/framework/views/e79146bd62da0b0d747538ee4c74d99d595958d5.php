<?php $__env->startSection('title','Home'); ?>
<?php $__env->startSection('content'); ?>
    <div class='container'>
        <div class='col-md-12 p-4 d-flex align-items-center justify-content-center'>
            <div class="card" style="border-radius: 15px;">
                <div class="card-body p-5">
                    <div class='col-md-12 align-items-center justify-content-center' display="inline-block">
                        <h2 class="text-center m-5" ">Login</h2>
                        <?php if($errors->any()): ?>
                        <div class="text-danger mt-2 text-sm"><?php echo e($errors->first('message')); ?></div> 
                        <?php endif; ?>
                    </div>
                    <div class="col-md-12 d-flex flex-column align-items-center justify-content-center">
                        <form class="" action="<?php echo e(route("login")); ?>" method="post">  
                            <?php echo csrf_field(); ?>     
                            <div class="form-outline mb-4">
                                <input class="form-control form-control-lg" type="text" name="username" id="username"
                                placeholder="Your username" value="<?php echo e(old('username')); ?>"/>
                                <?php $__errorArgs = ["username"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                <div class="text-danger mt-2 text-sm"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-outline mb-4">
                                <input class="form-control form-control-lg" type="password" name="password" id="password" 
                                placeholder="Enter your password"/> 
                                <?php $__errorArgs = ["password"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                <div class="text-danger mt-2 text-sm"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>     
                            </div>
                            <div class="d-flex justify-content-center">
                                <button type="submit" class="btn btn-success btn-block btn-lg gradient-custom-4 text-body">Log In</button>
                            </div>

                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
<script current="login">
    var tableFields = document.getElementById("navbarButtonsDiv");
    var children = tableFields.children;
    for (var i = 0; i < children.length; i++) {
        var element = children[i];
        if(element.classList.contains("active"))
        {
            element.classList.remove('active');
            element.setAttribute("aria-current","none");
            break;
        }
    }
    var reg = document.getElementById("login");
    reg.classList.add('active');                  
    reg.setAttribute("aria-current", "page");  
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\MnKWeather\resources\views/auth/login.blade.php ENDPATH**/ ?>